#include "stdafx.h"
#include <fstream>
#include <iostream>
#include <Windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <mysql.h> //����mysql����
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/core/mat.hpp>
#include <opencv2/core/operations.hpp>
#include <opencv2/core/wimage.hpp>
#include <opencv/cxcore.h>
#include <opencv/cv.h>
#include <math.h>
#include <wchar.h>
#include <list>
#include <time.h>
#include <ctime>
#include <strstream>
#include <direct.h>
#include <ctype.h>
#include <omp.h>
using namespace std;
using namespace cv;
//////////////////////////////////////////////////////////////////////////
struct TargetNode		//���Լ�¼ÿ֡��Ч��ͼ��·��
{
	bool mark;			//����Ƿ���������Ϣ
	int fps;			//��¼��֡��˳��
	string info;		//��������������Ϣ��û�еĻ���Ĭ��Ϊ"#"
	string path;		//��¼���洢��ͼƬ·��
};
struct SensitiveInfo
{
	string time;
	string info;
	int infotype;
	bool isSensitive;
};
//////////////////////////////////////////////////////////////////////////
int ocr_num=0;
void  readfile(int target,int fpsnum);	                         //��ȡ��OCR ���ɵ�txt�ļ�,���������ݿ⴦��
bool  DBconnect();									 //���ݿ����ӣ�ȫ�����ӣ�������һ��ʼ���������ݿ�
bool  DBdisconnect();								  //���ݿ�Ͽ������в������֮��Ͽ����ݿ�
bool  DBop(string body,string head,int order,int fps);		  //���ݿ������ͨ���ַ����Ƚ���������Ϣ��
void  DBinsertResult(string body,string timepoint,string fpsnum);	   //���õ��Ľ����һ���ĸ�ʽ�洢
void  getRect(Mat image);							   //ȡ��Ŀ��ķ�Χ��
void  processVideo(VideoCapture& capture);				   //������Ƶ�Ľӿ����
void  target_Pro(string temp,int target,string path);	//��Ŀ���������н��в���������������������ӵ�������
void  read_target_info(int target);						 //�ڵȴ�һ��ʱ��󣬿�ʼ����Ŀ�������е�Ԫ��
void  setUser(string newuser);							 //���ݿ��û�����
void  setPassword(string newpassword);					 //���ݿ���������
void  setDatabase(string newdatabase);					 //���ݿ�ʵ������
void  setPort(unsigned newPort);						 //���ݿ�port�ӿ�����
void  setTable(string newtable);						 //���ݿ������
void  setResultTable(string newresulttable);          	 //������ݿ�����
void  clear_picfile();									 //����ļ��е��ݴ�ͼƬ
std::vector<SensitiveInfo> DBgetResult(string video_name);     //�ڴ������֮���ɴ˺��������ݿ���ȡ�ô��������Ϣ
void  processPic(cv::Mat sample);							  //��ͼƬ��������Ƶ�����ֿ����˺�������ͼƬ����
//////////////////////////////////////////////////////////////////////////
int   width =0;
int   heigh =0;
Rect  TOP; //�������ַ�����ֲ�����
Rect  DOWN;//�ײ����ַ�����ֲ�����
Rect  TOP_temp;//�������ַ�����ֲ�������ʱ�洢�����Խ������ıȽ�
Rect  DOWN_temp;//�ײ����ַ�����ֲ�������ʱ�洢�����Խ������ıȽ�
int   top=100; //��ʼֵ�����Ե��ڶ������εĸ�
int   down=30; //��ʼֵ�����Ե��ڵײ����εĸ�
int   temp_position=0;
int   fps_per_second=0;//�������ṩ����Ƶ��ÿ��֡��
///////////////////////////////////////////////////////
Mat   target1;//Ŀ��1�Ĵ洢����
Mat   target2;//Ŀ��2�Ĵ洢����
Mat   target1_temp;//Ŀ��1����ʱ�洢����	�������Ժ���бȽ�
Mat   target2_temp;//Ŀ��2����ʱ�洢����	�������Ժ���бȽ�
time_t begintime; //��ʼʱ��
time_t endtime;	  //����ʱ��
struct tm * timeinfo;
//////////////////////////////////////////////////////////////////////////
string   user =     "root";		//	���ݿ��û���
string   password = "123456";	 //	 ���ݿ��������
string   host =     "localhost";  //  ���ݿ�����
string   database=  "data";		   //  ���ݿ�ʵ��
string   table=     "info";			//	���ݿ���������Ϣ�Ĵ洢��
string   resulttable=" result";		 //	 ���ݿ��еķ�������洢��
unsigned int  port = 3306;			  //  
//////////////////////////////////////////////////////////////////////////
MYSQL        mycon;
MYSQL_RES  * resualt;
MYSQL_ROW    sql_row;
MYSQL_FIELD *field;
//////////////////////////////////////////////////////////////////////////
//���ݿ�ĸ���Դ������mysql��ΪĬ�ϵ����ݿ�
//�����ڽ��и������ݿ�
//
//
//////////////////////////////////////////////////////////////////////////
cv::Mat  kernel1(23,23,CV_8U,cv::Scalar(1));
cv::Mat  kernel2(23,23,CV_8U,cv::Scalar(1));
//////////////////////////////////////////////////////////////////////////
bool   db =  false;   //���ݿ��Ƿ�����
int    fps_num = 0;     //��¼��Ƶ��ȡ��֡��
string videoname;	//��Ƶ����
//////////////////////////////////////////////////////////////////////////
string target1_node_temp;			//ͼƬ�е�������Ϣ���ݴ���	��target1��Ŀ��1
bool target1_mark = false;		   //ͼƬ����ʱ�����trueΪ������Ϣ��target1��Ŀ��1
string target2_node_temp;			//ͼƬ�е�������Ϣ���ݴ���	��target2��Ŀ��2
bool target2_mark = false;		   //ͼƬ����ʱ�����trueΪ������Ϣ��target2��Ŀ��2
list<TargetNode> target1_list;	    //��Ч��ͼƬ�б� target1
int target1_num = 1;			   //ͼƬ���б���ʱ��һ��ȫ�ֱ���	��target1��Ŀ��1
list<TargetNode> target2_list;	    //��Ч��ͼƬ�б�  target2
int target2_num = 1;			   //ͼƬ���б���ʱ��һ��ȫ�ֱ���	��target2��Ŀ��2
vector<SensitiveInfo> infolist;     //������ĿҪ���ĵ�������Ľ������������ӽ�����ݿ��ռ�������Ϣ
//////////////////////////////////////////////////////////////////////////
void clear_picfile()
{
	cout<<"���в�������ɾ������������ݴ�ͼƬ����ѡ��Y"<<endl;
	system("DEL pic1");
	system("DEL pic2");
};
void target_Pro(string temp,int target,string path)
{	
	if (target==1)
	{
		TargetNode newnode;
		newnode.fps=fps_num;
		newnode.info.assign(temp.c_str());
		newnode.path.assign(path.c_str());
		target1_list.push_back(newnode);
	}
	if (target==2)
	{
		TargetNode newnode;
		newnode.fps=fps_num;
		newnode.info.assign(temp.c_str());
		newnode.path.assign(path.c_str());
		target2_list.push_back(newnode);
	}
	return ;
};

void read_target_info(int target)
{
	list<TargetNode>::iterator target_iterator;
	if (target==1)
	{
		Mat target1_collection;
		string str1_exe;
		for (target_iterator=target1_list.begin();target_iterator!=target1_list.end();target_iterator++)
		{
			str1_exe.append("tesseract.exe ").append(target_iterator->path).append(" target1  -l chi_sim");
			system(str1_exe.c_str());

			readfile(1,target_iterator->fps);
			target_iterator->mark=target1_mark;
			target1_mark=false;
			target_iterator->info.clear();
			target_iterator->info.assign(target1_node_temp.c_str());
			target1_node_temp.clear();
			str1_exe.clear();
		}
	}
	if (target==2)
	{
		Mat target2_collection;
		string str2_exe;
		for (target_iterator=target2_list.begin();target_iterator!=target2_list.end();target_iterator++)
		{
			str2_exe.append("tesseract.exe ").append(target_iterator->path).append(" target2  -l chi_sim");
			system(str2_exe.c_str());
			ocr_num++;
			readfile(2,target_iterator->fps);
			target_iterator->mark=target2_mark;
			target2_mark=false;
			target_iterator->info.clear();
			target_iterator->info.assign(target2_node_temp.c_str());
			target2_node_temp.clear();
			str2_exe.clear();
		}
	}
	return ;
};
void setVideoname(string newvideoname)
{
	videoname=newvideoname;
};
void setUser(string newuser)
{
	user=newuser;
	return ;
};
void setPassword(string newpassword)
{
	password=newpassword;
	return ;
};
void setDatabase(string newdatabase)
{
	database=newdatabase;
};
void setPort(unsigned newPort)
{
	port=newPort;
};
void setTable(string newtable)
{
	table=newtable;
	return ;
};
void setResultTable(string newresulttable)
{
	resulttable=newresulttable;
};
bool DBconnect()
{
	if (db)
	{
		return true;
	}
	mysql_init(&mycon);
	if (mysql_real_connect(&mycon,host.c_str(),user.c_str(),password.c_str(),database.c_str(),port,NULL,0))
	{
		mysql_query(&mycon,"set names GBK");
		db = true;
		return true;
	}
	else
	{
		db = false;
		return false;
	}
};
bool  DBdisconnect()
{
	if (!db)
	{
		return false;
	}
	try
	{
		mysql_close(&mycon);
		return true;
	}
	catch (Exception* e)
	{
		mysql_close(&mycon);
	}
	return false;

};
bool DBop(string body,string head,int order,int target,int fpsnum)
{
	if (!db)
	{
		return false;
	}
	int hcount=0,mcount=0,scount=0;
	strstream sbuf;
	string s1,s2,s3,s4;
	if (order==1)
	{
		mysql_query(&mycon,"SET NAMES GBK");
		string sql="insert into " ;
		sql.append(table);
		sql.append(" (head, body ) values ( '");
		sql.append(head);
		sql.append("','");
		sql.append(body);
		sql.append(" ')");
		mysql_query(&mycon,sql.c_str());
		return true;
	}
	if (order==2)
	{
		char column[32][32];
		string sql="select * from " ;
		sql.append(table);
		sql.append(" where head = '");
		sql.append(head);
		sql.append("'");
		mysql_query(&mycon,sql.c_str());
		resualt=mysql_store_result(&mycon);
		if (resualt)
		{
			int i,j=0;
			if ((unsigned long)mysql_num_rows(resualt)==0)
			{
				return false;
			}
			j=mysql_num_fields(resualt);
			while (sql_row=mysql_fetch_row(resualt))
			{	
				for (i=2;i<j;i++)
				{
					string temp(sql_row[i]);

					if (temp==body.substr(0,temp.length()))
					{
						if (target==0)
						{
							DBinsertResult(temp,"#","#");
						}
						if (target==1)
						{
							target1_mark=true;
							target1_node_temp.assign(temp.c_str());
							hcount=(fpsnum/fps_per_second+1)/3600;
							sbuf << hcount;
							sbuf >> s1;
							sbuf.clear();
							mcount=((fpsnum/fps_per_second+1)-hcount*3600)/60;
							sbuf << mcount;
							sbuf >> s2;
							sbuf.clear();
							scount=((fpsnum/fps_per_second+1)-hcount*3600-mcount*60);
							sbuf << scount;
							sbuf >> s3;
							sbuf.clear();
							s1.append(":").append(s2).append(":").append(s3);
							sbuf << fpsnum;
							sbuf >> s4;
							sbuf.clear();
							DBinsertResult(temp,s1,s4);
							s1.clear();s2.clear();s3.clear(),s4.clear();
						}
						if (target==2)
						{
							target2_mark=true;
							target2_node_temp.assign(temp.c_str());
							hcount=(fpsnum/fps_per_second+1)/3600;
							sbuf << hcount;
							sbuf >> s1;
							sbuf.clear();
							mcount=((fpsnum/fps_per_second+1)-hcount*3600)/60;
							sbuf << mcount;
							sbuf >> s2;
							sbuf.clear();
							scount=((fpsnum/fps_per_second+1)-hcount*3600-mcount*60);
							sbuf << scount;
							sbuf >> s3;
							sbuf.clear();
							s1.append(":").append(s2).append(":").append(s3);
							sbuf << fpsnum;
							sbuf >> s4;
							sbuf.clear();
							DBinsertResult(temp,s1,s4);
							s1.clear();s2.clear();s3.clear();s4.clear();
						}
					}
				}
			}
		}
		else
		{
			return false;
		}
		if (resualt!=NULL)
		{
			mysql_free_result(resualt);
		}
		return true;
	}

};
void DBinsertResult(string body,string timepoint,string fpsnum)
{
	mysql_query(&mycon,"set names GBK");
	string sql="insert into  " ;
	sql.append(resulttable);
	sql.append("(video, info ,timepoint ,fpsnum) values ( '");
	sql.append(videoname);
	sql.append("','");
	sql.append(body);
	sql.append("','");
	sql.append(timepoint);
	sql.append("','");
	sql.append(fpsnum);
	sql.append(" ')");
	mysql_query(&mycon,sql.c_str());
	return ;
} ;
std::vector<SensitiveInfo> DBgetResult(string video_name)
{
	SensitiveInfo * result;
	string sql="select * from result " ;
	sql.append(" where video = '");
	sql.append(video_name);
	sql.append("'");
	mysql_query(&mycon,sql.c_str());
	resualt=mysql_store_result(&mycon);
	if (resualt)
	{
		if((unsigned long)mysql_num_rows(resualt)==0)
		{
			result=new SensitiveInfo;
			result->isSensitive=false;
			result->infotype= 0;
			result->info="#";
			result->time="#";
			infolist.push_back(*result);
			return infolist;
		}

		while (sql_row=mysql_fetch_row(resualt))
		{
			result=new SensitiveInfo;
			result->isSensitive=true;
			result->infotype= 0;
			result->info=sql_row[3];
			result->time=sql_row[4];
			infolist.push_back(*result);
		}
		mysql_free_result(resualt);
		return infolist;
	}
	else
	{
		result=new SensitiveInfo;
		result->isSensitive=false;
		result->infotype= 0;
		result->info="#";
		result->time="#";
		infolist.push_back(*result);
		return infolist;
	}
} ;
void getRect(Mat image)
{
	Mat src;
	Mat dst, cdst;
	cvtColor(image,src,CV_BGR2GRAY);
	Canny(src, dst,10,100,3,false);
	cvtColor(dst, cdst, CV_GRAY2BGR);
	vector<Vec4i> lines;
	HoughLinesP(dst, lines, 1, CV_PI/180, 60,30,20 );
	for( size_t i = 0; i < lines.size(); i++ )
	{
		Vec4i l = lines[i];
		if (l[1]>l[3]+4||l[1]<l[3]-4||l[2]-l[0]<(src.cols*0.6))
		{	
			continue;
		}
		//////////////////////////////////////////////////////////////////////////
		temp_position=(l[1]+l[3])/2;
		if ((temp_position<top)&&(temp_position<src.rows/2)&&(temp_position>src.rows/10))
		{
			top=temp_position;
		}
		if ((temp_position>down)&&(temp_position>src.rows/2)&&(temp_position>src.rows/10))
		{
			down=temp_position;
		}	
	}
	if ((src.rows-down)<(src.rows-down+top)/2)
	{
		down= src.rows-top;
	}
	if (top<(src.rows-down+top)/2)
	{
		top= src.rows-down;
	}
	TOP.x=0;
	TOP.y=0;
	TOP.width=src.cols;
	TOP.height=top;
	DOWN.x=0;
	DOWN.y=down;
	DOWN.width=src.cols;
	DOWN.height=src.rows-down;
	cv::rectangle(src,TOP,Scalar(255,255,255),1,8);
	cv::rectangle(src,DOWN,Scalar(255,255,255),1,8);
	imshow("detected lines", src);
	return ;
};

void readfile(int target,int fpsnum)
{   
	string   body;
	string   head;
	wchar_t  buf[2];
	FILE   * file;
	wstring  wstr;
	int fileend_mark=0;
	if (target==1)
	{
		file  =  _wfopen(L"target1.txt ",L"rt+,ccs=UTF-8"); 
	}
	else if (target==2)
	{
		file  =  _wfopen(L"target2.txt ",L"rt+,ccs=UTF-8");
	} 
	else if (target==0)
		{
			file  =  _wfopen(L"sample.txt ",L"rt+,ccs=UTF-8");
		}
	locale loc(""); 
	while(!feof(file)) 
	{ 
		fgetws(buf,2,file);
		if (buf[0]==10)									  
		{
			fileend_mark++;
			continue;
		}
		if (fileend_mark>=2)
		{
			break;
		}
		fileend_mark=0;
		wstr.append(buf);
	}
	fclose(file);
	//////////////////////////////////////////////////////////////////////////
	string curlocal=setlocale(LC_ALL,NULL);
	setlocale(LC_ALL,"");
	//////////////////////////////////////////////////////////////////////////
	const wchar_t *source;
	size_t temp_size = 0;
	size_t head_size=0;
	char * temp = NULL;
	char * head_temp=NULL;
	for (int i=0;i<wstr.length();i++)
	{
		source = &wstr.c_str()[i];
		temp_size = 2 * (wstr.size()-i)+ 1;
		head_size=2+1;
		temp = new char[temp_size];
		head_temp=new char[head_size];
		memset(temp,0,temp_size);
		memset(head_temp,0,2+1);
		wcstombs(temp,source,temp_size);
		wcstombs(head_temp,source,2+1);
		body = temp;
		head = head_temp;
 		if (i==0)
 		{
 			cout<<head<<"  head  "<<endl;
 			cout<<body<<"  body  "<<endl;
 		}
		{
			if (target==0)
			{
				DBop(body,head,2,target,fpsnum);
				continue;
			}
			else
				{
					DBop(body,head,2,target,fpsnum);
				}
		}
	}							  	
	//////////////////////////////////////////////////////////////////////////
	setlocale(LC_ALL,curlocal.c_str());
	delete [] temp;
	delete [] head_temp;
};
void processPic(cv::Mat sample)
	{
		time ( &begintime );
		{
 		cv::Mat sample_temp;
 		cv::pyrUp(sample,sample_temp);
 		sample.release();
 		sample=sample_temp.clone();
 		}
		cv::imwrite("sample.jpg", sample);
		std::string pic_str_exe;
		pic_str_exe.append("tesseract.exe ").append(" sample.jpg ").append(" sample  -l chi_sim");
		system(pic_str_exe.c_str());
		readfile(0,0);
		time ( &endtime );
		endtime=endtime-begintime;
		timeinfo = localtime ( &endtime );
		pic_str_exe.clear();
		cout<<"   ��ʱ:  "<<timeinfo->tm_hour<<" : "<<timeinfo->tm_min<<" : "<<timeinfo->tm_sec<<endl;
	};
void processVideo(VideoCapture& capture)
{	
	bool over1=false,
		over2=false,
		over3=false;
	cv::Mat target1_open_op;
	cv::Mat target2_open_op;
	fps_per_second=capture.get(CV_CAP_PROP_FPS);
	time ( &begintime );
#pragma omp parallel for
	for (int op=1;op<=3;op++)
	{
		if (op==1)
		{
			char pathname1[50];
			char pathname2[50];
			Mat frame;
			Mat target1_dst_sub;
			Mat target2_dst_sub;
			bool readpic=true;
			fps_num=1;
			while (readpic) {
				capture>>frame;
				if (frame.empty())
				{
					over1=true;
					if (over1==true&&over2==true&&over3==true)
					{ 
						Sleep(2000);
						readpic=false;
					}
					else
					{
						Sleep(2000);
						continue;
					}
				}
				if ((fps_num%fps_per_second)!=0)
				{
					fps_num++;
					continue;
				}
				fps_num++;
				getRect(frame);
				target1=frame(TOP);
				{
					cv::Mat sample_temp;
					cv::cvtColor(target1,sample_temp,CV_BGR2GRAY);
					target1.release();
					target1=sample_temp.clone();
				}
				sprintf(pathname1, "pic1/100%d.jpg", target1_num);
				target1_num++;
				{
					cv::Mat sample_temp;
					cv::pyrUp(target1,sample_temp);
					target1.release();
					target1=sample_temp.clone();
				}
				float target1_mean=cv::mean(target1).operator[](0);
				cv::morphologyEx(target1,target1_open_op,MORPH_TOPHAT,kernel1,cv::Point(-1,-1),1,0);
				threshold(target1_open_op,target1_open_op,50+target1_mean,255,CV_THRESH_BINARY);
				cv::imwrite(pathname1,target1_open_op);
				if(target1_mean>2.5)
				{
					
					if ((TOP.width!=TOP_temp.width||TOP.height!=TOP_temp.height))
					{
						target_Pro("#",1,pathname1);
						TOP_temp.x=TOP.x;
						TOP_temp.y=TOP.y;
						TOP_temp.width=TOP.width;
						TOP_temp.height=TOP.height;
					}
					else
					{
						cv::subtract(target1,target1_temp,target1_dst_sub);
						threshold(target1_dst_sub,target1_dst_sub,128,255,CV_THRESH_BINARY);
						if ((cv::mean(target1_dst_sub).operator[](0)>10.0))
						{   	    
							target_Pro("#",1,pathname1);
						}
					}
					target1_temp=target1.clone();
					target1.release();
				}
				else
					{
						target1_temp=target1.clone();
						target1.release();
					}
				//////////////////////////////////////////////////////////////////////////
				target2=frame(DOWN);
				{
					cv::Mat sample_temp;
					cv::cvtColor(target2,sample_temp,CV_BGR2GRAY);
					target2.release();
					target2=sample_temp.clone();
				}
				sprintf(pathname2, "pic2/200%d.jpg", target2_num);
				target2_num++;
				float target2_mean=cv::mean(target2).operator[](0);	
				{
					cv::Mat sample_temp;
					cv::pyrUp(target2,sample_temp);
					target2.release();
					target2=sample_temp.clone();
				}
				cv::morphologyEx(target2,target2_open_op,MORPH_TOPHAT,kernel2,cv::Point(-1,-1),1,0);
				threshold(target2_open_op,target2_open_op,100+target2_mean,255,CV_THRESH_BINARY);
				cv::imwrite(pathname2,target2_open_op);
				if(target2_mean>5.0)
				{
					if (DOWN.width!=DOWN_temp.width||DOWN.height!=DOWN_temp.height)
					{
						target_Pro("#",2,pathname2);
						//////////////////////////////////////////////////////////////////////////
						DOWN_temp.x=DOWN.x;
						DOWN_temp.y=DOWN.y;
						DOWN_temp.width=DOWN.width;
						DOWN_temp.height=DOWN.height;
					}
					else
					{
						cv::subtract(target2,target2_temp,target2_dst_sub);
						threshold(target2_dst_sub,target2_dst_sub,128,255,CV_THRESH_BINARY);
						if ((cv::mean(target2_dst_sub).operator[](0)>5.0))
						{ 
							target_Pro("#",2,pathname2);
						}
					}
					target2_temp=target2.clone();
					target2.release();
				}
				else
				{
					target2_temp=target2.clone();
					target2.release();
				}
				waitKey(1);
			}
			target1_dst_sub.release();
			target2_dst_sub.release();
		}
		if (op==2)
		{
			Sleep(8000);
			cout<<"2 start"<<endl;
			read_target_info(1);
			over2=true;
		}
		if (op==3)
		{
			Sleep(5000);
			cout<<"3 start"<<endl;
			read_target_info(2);
			over3=true;
		}
	}
	time ( &endtime );
	endtime=endtime-begintime;
	timeinfo = localtime ( &endtime );
	cout<<"��ʱ��"<<timeinfo->tm_hour<<" : "<<timeinfo->tm_min<<" : "<<timeinfo->tm_sec<<endl;
	cout<<" OCR time"<<ocr_num<<endl;
	target1.release();
	target1_temp.release();
	target2.release();
	target2_temp.release();
	return ;
};
